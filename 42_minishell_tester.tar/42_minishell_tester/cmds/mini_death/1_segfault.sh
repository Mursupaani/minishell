echo |< echo segf

echo segf >| echo is this invalid

echo >          >           < "echo"

echo >          >         | echo kekw

echo >          >         | echo super valid

echo <          <         > echo

echo <  < <         > ok

echo <  < | echo ok

echo <  < |    < ok

echo <      < |    > echo

echo >>| echo super valid

echo >>< "echo"

echo < < < echo seegf

echo > > < "echo"

echo > > | echo kekw

echo > > | echo super valid

echo < < > echo

echo < < < > ok

echo >>| echo kekw

echo | < echo segf

echo <<| echo ok

echo <<|< ok

echo <<|> echo

echo <<> echo

echo <<<> ok

echo segfault <"<<<"<<amazing
.
amazing

echo seg < > echo seg

echo seg > < echo segf

echo seg < < > echo segf

echo seg < < < > echo segf

echo segf > | echo is this invalid

echo segf < | < echo super valid

echo < < | echo ok

echo < < | < ok

echo < < | > echo

echo segfault < " < < < " < < amazing
.
amazing

echo seg <  > echo seg

echo seg >  < echo segf

echo seg <      < > echo segf

echo seg <      < <    > echo segf

echo <      <     < echo seegf

echo |      < echo segf

echo segf >     | echo is this invalid

echo segf <         |        < echo super valid

echo segfault <"    <   <   <"  <   <   amazing
.
amazing

echo seg <> echo seg

echo seg >< echo segf

echo seg <<> echo segf

echo seg <<<> echo segf

echo <<< echo seegf

echo segf <|< echo super valid

echo test |  <<lala

echo | > la

echo yolo | eco test >> test

echo echo echo echo echo echo

unset $PATH
ECHO -nnnn

unset $PATH
ECHO -n

unset $PATH
ECHo -n

unset $PATH
ECHO "-n"

unset $PATH
EcHO -nnnn

unset $PATH
echo -nnnnnnnn








