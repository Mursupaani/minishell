unset PATH
ls

unset PATH
env

env

export

echo $USER

echo $HOME

echo $HOME$NOTHING$USER$

pwd

unset PATH
echo $HOME$NOTHING$USER$

unset PATH

unset USER

cd -
pwd

echo "no env over here"

exit asd

exit 5

exit 5 asd

unset OLDPWD
cd -
pwd

cd
cd ~

/bin/ls

cd /bin/
./ls
ls

export T=bazd
echo "$T" "meg"

cd /bin/
ls

export a="asd" b="de" o= c="hellomi" X
unset o

export a="asd" b="de" o= c="hellomi" X
unset X

export a="asd" b="de" o= c="hellomi" X
unset o a X b c

export a="asd" b="de" o= c="hellomi" X
unset o asd B x X wqd c

unset PATH
cat
cd ..
exit

unset PATH
pwd
cd
pwd

unset PATH
pwd
cd -
pwd
exit

unset PATH
pwd
cd ~
pwd

unset PATH
pwd
cd ~
pwd
cd -
pwd

/bin/cat Makefile > out >>out1 >out2
/bin/cat Makefile > out >>out1 >out2
/bin/rm -rf out
/bin/rm -rf out1
/bin/rm -rf out2

/bin/cat Makefile > out >>out1 >out2 | /bin/cat << stop > out3
asdsada
asd
stop
/bin/cat Makefile > out >>out1 >out2 | /bin/cat << stop > out3
123
123
12
stop
/bin/rm -rf out
/bin/rm -rf out1
/bin/rm -rf out2
/bin/rm -rf out3

/bin/cat Makefile > out >>out1 >out2 | /bin/cat << stop > out3 | /bin/ls
testinator
stop
/bin/rm -rf out
/bin/rm -rf out1
/bin/rm -rf out2
/bin/rm -rf out3

/bin/cat Makefile > out >>out1 >out2 | /bin/cat << stop > out3 | /bin/ls > > | /bin/cat << file
will make you cry
stop
/bin/rm -rf out
/bin/rm -rf out1
/bin/rm -rf out2
/bin/rm -rf out3
cd ..
pwd

/bin/cat Makefile > out >>out1 >out2 > out3 >> out4
/bin/cat Makefile > out >>out1 >out2 > out3 >> out4
/bin/rm -rf out
/bin/rm -rf out1
/bin/rm -rf out2
/bin/rm -rf out3
/bin/rm -rf out4

> out
/bin/rm -rf out

< out
/bin/rm -rf out

|

""

''

>> out
/bin/rm -rf out

<< out
where
is
MY
ENV?
BRING IT BACK!
out

i hope you enjoy it
